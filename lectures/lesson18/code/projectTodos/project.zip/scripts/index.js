const todoList = [];

async function fetchTodos() {
  try {
      const response = await fetch('https://jsonplaceholder.typicode.com/todos');
      const data = await response.json();
      const limitedData = data.slice(0, 25).map(item => ({
        task: item.title,
        done: item.completed
    })); // Берем только первые 5 задач
      todoList.push(...limitedData);
      core(todoList);
  } catch (error) {
      console.error('Error fetching todos:', error);
  }
}

function core(arrList) {
    const list = document.querySelector('.list');
    list.innerHTML = ''; // очищаем старый массив

    const createElem = arrList.map(item => {
        const listItem = document.createElement('li');
        listItem.textContent = item.task;
        listItem.classList.add('list-item');
        if (item.done) {
            listItem.classList.add('list-item_done');
        }
        listItem.addEventListener('click', () => {
            if (!item.done) {
                listItem.classList.add('list-item_done');
                item.done = true;
            } else {
                listItem.classList.remove('list-item_done');
                item.done = false;
            }
        });
        return listItem;
    });

    createElem.forEach(listItem => {
        list.appendChild(listItem);
    });
}

// Инициализация списка задач при загрузке страницы
fetchTodos();

// кнопка "Создать"
const btnCreate = document.querySelector('#create');
const inputTask = document.querySelector('.task-input');

const btnClickCreate = () => {
    const textFromInput = inputTask.value;
    if (textFromInput.trim() !== "") {
        todoList.unshift({ title: textFromInput, completed: false });
        core(todoList);
    }
}
btnCreate.addEventListener('click', btnClickCreate);

// Фильтры
const filter = document.querySelector('.status');

// Фильтр "все"
const btnAll = document.querySelector('#all');

const btnClickAll = () => {
    core(todoList);
}
btnAll.addEventListener('click', btnClickAll);

// Фильтр "выполненные"
const btnCompleted = document.querySelector('#completed');

const btnClickCompleted = () => {
    const filterCompleted = todoList.filter(task => task.completed);
    core(filterCompleted);
}
btnCompleted.addEventListener('click', btnClickCompleted);

// Фильтр "невыполненные"
const btnUnCompleted = document.querySelector('#uncompleted');

const btnClickUCompleted = () => {
    const filterUnCompleted = todoList.filter(task => !task.completed);
    core(filterUnCompleted);
}
btnUnCompleted.addEventListener('click', btnClickUCompleted);
